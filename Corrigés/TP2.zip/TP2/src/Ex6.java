
public class Ex6 {
	public static void main(String[] args) {
		Operation op = new Operation();
		op.setOperande1(1);
		op.setOperande2(2);
		op.setOperateur("+");
		
		System.out.println(op.calcul());
	}
}
