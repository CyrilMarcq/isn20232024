import java.util.Scanner;

public class Ex3 {

	public static void main(String[] args) {
		System.out.print("Entrez en une chaine :");
		Scanner scann = new Scanner(System.in);
		String chaine = scann.next();

		char[] chainesCaract = chaine.toCharArray();

		for (int i = 0; i < chainesCaract.length; i++) {
			if (i % 2 == 0) {
				chainesCaract[i] = '*';
			}
		}

		System.out.println(String.valueOf(chainesCaract));

		scann.close();
	}
}
