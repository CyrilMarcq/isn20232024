
public class Ex8 {

	
	
	
	public static void main(String[] args) {
		
		final Voiture voit1 = new Voiture();
		
		final Voiture voit2 = new Voiture("Renault", "Clio", "AA-123-AA");
		
		final Voiture voit3 = new Voiture(voit2);
		
		System.out.println(voit1.afficherInformations());
		System.out.println("");
		System.out.println(voit2.afficherInformations());
		System.out.println("");
		System.out.println(voit3.afficherInformations());
	}
}
