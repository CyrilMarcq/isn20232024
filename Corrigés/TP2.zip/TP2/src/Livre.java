
/**
 * @author marcq
 *
 */
public class Livre {

	private String nomAuteur;

	private String prenomAuteur;

	private String categorie;

	private String isbn;

	public String afficherInformations() {
		return "Nom de l'auteur : " + this.nomAuteur + "\n" + "Prénom de l'auteur : " + this.prenomAuteur + "\n"
				+ "Categorie : " + this.categorie + "\n" + "ISBN : " + this.isbn;
	}

	public String recupererCodeProduit() {
		return "" + this.nomAuteur.charAt(0) + this.prenomAuteur.charAt(1) + this.categorie.charAt(0)
				+ this.isbn.charAt(this.isbn.length() - 2) + this.isbn.charAt(this.isbn.length() - 1);
	}

	// Getter / setter

	/**
	 * @return
	 */
	public String getNomAuteur() {
		return nomAuteur;
	}

	/**
	 * @param nomAuteur
	 */
	public void setNomAuteur(final String nomAuteur) {
		this.nomAuteur = nomAuteur;
	}

	/**
	 * @return
	 */
	public String getPrenomAuteur() {
		return prenomAuteur;
	}

	/**
	 * @param prenomAuteur
	 */
	public void setPrenomAuteur(final String prenomAuteur) {
		this.prenomAuteur = prenomAuteur;
	}

	/**
	 * @return
	 */
	public String getCategorie() {
		return categorie;
	}

	/**
	 * @param categorie
	 */
	public void setCategorie(final String categorie) {
		this.categorie = categorie;
	}

	/**
	 * @return
	 */
	public String getIsbn() {
		return isbn;
	}

	/**
	 * @param isbn
	 */
	public void setIsbn(final String isbn) {
		this.isbn = isbn;
	}

}
