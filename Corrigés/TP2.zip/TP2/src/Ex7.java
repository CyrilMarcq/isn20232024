
public class Ex7 {

	public static void main(String[] args) {
		Etudiant etud = new Etudiant();
		etud.setNom("Nom");
		etud.setPrenom("Prenom");
		etud.setNote1(15);
		etud.setNote2(10);
		
		System.out.println("Initiales : " + etud.initiales());
		System.out.println("Trigrammes : " + etud.genererTrigramme());
		System.out.println("Moyenne " + etud.calculerMoyenne());
	}
}
