
public class Voiture {

	private String marque;

	private String modele;

	private String immatriculation;

	/**
	 * Constructeur par défaut
	 */
	public Voiture() {
		this.marque = "";
		this.modele = "";
		this.immatriculation = "";
	}

	/**
	 * Constructeur par recopie
	 * 
	 * @param voiture
	 */
	public Voiture(final Voiture voiture) {
		this.marque = voiture.marque;
		this.modele = voiture.modele;
		this.immatriculation = voiture.immatriculation;
	}

	/**
	 * Constructeur par paramètres
	 * 
	 * @param marque
	 * @param modele
	 * @param immatriculation
	 */
	public Voiture(final String marque, final String modele, final String immatriculation) {
		this.marque = marque;
		this.modele = modele;
		this.immatriculation = immatriculation;
	}
	
	public String afficherInformations() {
		return "Marque : " + this.marque + "\n" + "Modèle : " + this.modele + "\n" + "Immatriculation : " + this.immatriculation;
	}
}
