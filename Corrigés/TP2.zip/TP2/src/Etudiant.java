
public class Etudiant {

	private String nom;

	private String prenom;

	private int note1;

	private int note2;

	/**
	 * Calcul de la moyenne des notes
	 * 
	 * @return
	 */
	public double calculerMoyenne() {
		return (double) (note1 + note2) / 2;
	}

	/**
	 * Génération des initiales
	 * 
	 * @return
	 */
	public String initiales() {
		return ("" + prenom.charAt(0) + nom.charAt(0)).toUpperCase();
	}

	/**
	 * Génération du trigramme
	 * 
	 * @return
	 */
	public String genererTrigramme() {
		return ("" + prenom.charAt(0) + nom.charAt(0) + nom.charAt(nom.length() - 1)).toUpperCase();
	}

	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	/**
	 * @return the prenom
	 */
	public String getPrenom() {
		return prenom;
	}

	/**
	 * @param prenom the prenom to set
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	/**
	 * @return the note1
	 */
	public int getNote1() {
		return note1;
	}

	/**
	 * @param note1 the note1 to set
	 */
	public void setNote1(int note1) {
		this.note1 = note1;
	}

	/**
	 * @return the note2
	 */
	public int getNote2() {
		return note2;
	}

	/**
	 * @param note2 the note2 to set
	 */
	public void setNote2(int note2) {
		this.note2 = note2;
	}

}
