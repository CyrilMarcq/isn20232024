import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		System.out.print("Entrez en une chaine :");
		Scanner scann = new Scanner(System.in);
		String chaine = scann.next();
		
		System.out.println("En majuscules : " + chaine.toUpperCase());
		System.out.println("En minuscules : " + chaine.toLowerCase());
		
		scann.close();
	}
}
