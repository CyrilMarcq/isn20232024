
public class Bibliotheque {

	private Livre livre1;

	private Livre livre2;

	/**
	 * Constructeur
	 */
	public Bibliotheque() {
		livre1 = new Livre();
		livre1.setNomAuteur("Auteur 1");
		livre1.setPrenomAuteur("Auteur 1");
		livre1.setCategorie("Categorie 1");
		livre1.setIsbn("ISBN1");
		livre2 = new Livre();
		livre2.setNomAuteur("Auteur 2");
		livre2.setPrenomAuteur("Auteur 2");
		livre2.setCategorie("Categorie 2");
		livre2.setIsbn("ISBN2");
	}

	/**
	 * Méthode affichant le contenu de la bibliothèque
	 * 
	 * @return contenu
	 */
	public String afficherContenu() {
		return livre1.afficherInformations() + "\n\n" + livre2.afficherInformations();

	}

	/**
	 * @return
	 */
	public Livre getLivre1() {
		return livre1;
	}

	/**
	 * @param livre1
	 */
	public void setLivre1(Livre livre1) {
		this.livre1 = livre1;
	}

	/**
	 * @return
	 */
	public Livre getLivre2() {
		return livre2;
	}

	/**
	 * @param livre2
	 */
	public void setLivre2(Livre livre2) {
		this.livre2 = livre2;
	}

}
