
public class Ex5 {

	public static void main(String[] args) {
		// Initialisation
		
		Triangle t = new Triangle();
		Point p1 = new Point();
		p1.setX(10);
		p1.setY(15);
		t.setP1(p1);
		Point p2 = new Point();
		p2.setX(30);
		p2.setY(20);
		t.setP2(p2);
		Point p3 = new Point();
		p3.setX(50);
		p3.setY(70);
		t.setP3(p3);
		
		t.setCote1(10);
		t.setCote2(20);
		t.setCote3(30);
		
		System.out.println("Périmètre : " + t.calculerPerimetre());
		System.out.println("Aire : " + t.calculerAire());
		System.out.println("Informations : " + t.afficherInformations());
		
		t.deplacerTriangle(10, 10);
		System.out.println("Après déplacement");
		
		System.out.println("Périmètre : " + t.calculerPerimetre());
		System.out.println("Aire : " + t.calculerAire());
		System.out.println("Informations : " + t.afficherInformations());
	}
}
