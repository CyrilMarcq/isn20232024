
public class Ex4 {

	public static void main(String[] args) {
		Bibliotheque bibliotheque = new Bibliotheque();
		System.out.println(bibliotheque.afficherContenu());
	}
}
