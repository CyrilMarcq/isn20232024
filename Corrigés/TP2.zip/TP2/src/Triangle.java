
public class Triangle {

	private Point p1;
	private Point p2;
	private Point p3;

	private int cote1;
	private int cote2;
	private int cote3;

	/**
	 * Calcule le périmètre du triangle
	 * 
	 * @return
	 */
	public int calculerPerimetre() {
		return cote1 + cote2 + cote3;
	}

	/**
	 * Calcule l'aire du triangle
	 * 
	 * @return
	 */
	public double calculerAire() {
		return 0.5 * cote1 * cote2 * Math.sin(cote3);
	}

	/**
	 * Affiche les informations du traingle
	 * 
	 * @return
	 */
	public String afficherInformations() {
		return "Point 1 : " + p1.afficherInformations() + "\n" + "Point 2 : " + p2.afficherInformations() + "\n"
				+ "Point 3 : " + p3.afficherInformations() + "\n";
	}

	/**
	 * Déplace le triangle
	 * 
	 * @param x coordonnées de déplacement de l'abscisse
	 * @param y coordonnées de déplacement de l'ordonnée
	 */
	public void deplacerTriangle(int x, int y) {
		p1.setX(p1.getX() + x);
		p1.setY(p1.getY() + y);
		p2.setX(p2.getX() + x);
		p2.setY(p2.getY() + y);
		p3.setX(p3.getX() + x);
		p3.setY(p3.getY() + y);
	}

	/**
	 * @return the p1
	 */
	public Point getP1() {
		return p1;
	}

	/**
	 * @param p1 the p1 to set
	 */
	public void setP1(Point p1) {
		this.p1 = p1;
	}

	/**
	 * @return the p2
	 */
	public Point getP2() {
		return p2;
	}

	/**
	 * @param p2 the p2 to set
	 */
	public void setP2(Point p2) {
		this.p2 = p2;
	}

	/**
	 * @return the p3
	 */
	public Point getP3() {
		return p3;
	}

	/**
	 * @param p3 the p3 to set
	 */
	public void setP3(Point p3) {
		this.p3 = p3;
	}

	/**
	 * @return the cote1
	 */
	public int getCote1() {
		return cote1;
	}

	/**
	 * @param cote1 the cote1 to set
	 */
	public void setCote1(int cote1) {
		this.cote1 = cote1;
	}

	/**
	 * @return the cote2
	 */
	public int getCote2() {
		return cote2;
	}

	/**
	 * @param cote2 the cote2 to set
	 */
	public void setCote2(int cote2) {
		this.cote2 = cote2;
	}

	/**
	 * @return the cote3
	 */
	public int getCote3() {
		return cote3;
	}

	/**
	 * @param cote3 the cote3 to set
	 */
	public void setCote3(int cote3) {
		this.cote3 = cote3;
	}

}
