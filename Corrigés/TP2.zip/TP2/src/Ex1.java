import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {

		Scanner scann = new Scanner(System.in);
		String chaine = scann.next();
		char[] maChaine = chaine.toCharArray();

		int nbCarac[] = new int[26];

		for (int i = 0; i < maChaine.length; i++) {
			char caract = maChaine[i];
			switch (caract) {
			case 'a':
				nbCarac[0]++;
				break;
			case 'b':
				nbCarac[1]++;
				break;
			case 'c':
				nbCarac[2]++;
				break;
			case 'd':
				nbCarac[3]++;
				break;
			case 'e':
				nbCarac[4]++;
				break;
			case 'f':
				nbCarac[5]++;
				break;
			case 'g':
				nbCarac[6]++;
				break;
			case 'h':
				nbCarac[7]++;
				break;
			case 'i':
				nbCarac[8]++;
				break;
			case 'j':
				nbCarac[9]++;
				break;
			case 'k':
				nbCarac[10]++;
				break;
			case 'l':
				nbCarac[11]++;
				break;
			case 'm':
				nbCarac[12]++;
				break;
			case 'n':
				nbCarac[13]++;
				break;
			case 'o':
				nbCarac[14]++;
				break;
			case 'p':
				nbCarac[15]++;
				break;
			case 'q':
				nbCarac[16]++;
				break;
			case 'r':
				nbCarac[17]++;
				break;
			case 's':
				nbCarac[18]++;
				break;
			case 't':
				nbCarac[19]++;
				break;
			case 'u':
				nbCarac[20]++;
				break;
			case 'v':
				nbCarac[21]++;
				break;
			case 'w':
				nbCarac[22]++;
				break;
			case 'x':
				nbCarac[23]++;
				break;
			case 'y':
				nbCarac[24]++;
				break;
			case 'z':
				nbCarac[25]++;
				break;
			}
		}

		for (int i = 0; i < nbCarac.length; i++) {
			System.out.println(nbCarac[i]);
		}

		scann.close();

	}
}
