
public class Operation {

	private int operande1;

	private int operande2;

	private String operateur;

	/**
	 * Méthode de calcul
	 * 
	 * @return
	 */
	public int calcul() {
		switch (operateur) {
		case "+":
			return operande1 + operande2;
		case "-":
			return operande1 + operande2;
		case "*":
			return operande1 + operande2;
		case "/":
			return operande1 + operande2;
		default:
			return 0;
		}
	}

	/**
	 * @return
	 */
	public int getOperande1() {
		return operande1;
	}

	/**
	 * @param operande1
	 */
	public void setOperande1(int operande1) {
		this.operande1 = operande1;
	}

	/**
	 * @return
	 */
	public int getOperande2() {
		return operande2;
	}

	/**
	 * @param operande2
	 */
	public void setOperande2(int operande2) {
		this.operande2 = operande2;
	}

	/**
	 * @return
	 */
	public String getOperateur() {
		return operateur;
	}

	/**
	 * @param operateur
	 */
	public void setOperateur(String operateur) {
		this.operateur = operateur;
	}

}
