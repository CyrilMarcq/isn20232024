
public class Ex7 {

	public static void main(final String[] args) {
		int annee = 2000;

		if (annee % 400 == 0 || (annee % 4 == 0 && annee % 100 != 0)) {
			System.out.println("Annee bissextile");
		} else {
			System.out.println("Année non bissextile");
		}
	}
}
