
public class Ex3 {

	public static void main(String[] args) {
		int rayon = 3;
		System.out.println("Le périmètre du cercle est : " + 2 * Math.PI * rayon);
	}
}
