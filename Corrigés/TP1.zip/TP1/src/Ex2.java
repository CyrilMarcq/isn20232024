
public class Ex2 {

	public static void main(final String[] args) {
		String maVariable = "Hello World";
		System.out.println(maVariable);
	}
}
