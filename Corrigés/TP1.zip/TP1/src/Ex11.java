
public class Ex11 {

	public static void main(final String[] args) {
		for (int i = 1; i < 255; i++) {
			System.out.println(i + ":" + (char) (i));
		}
	}
}
