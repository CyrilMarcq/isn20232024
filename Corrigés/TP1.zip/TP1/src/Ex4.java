import java.util.Scanner;

public class Ex4 {
	public static void main(String[] args) {
		System.out.print("Saisissez le rayon du cercle : ");
		Scanner scann = new Scanner(System.in);
		int rayon = scann.nextInt();
		System.out.println("Le périmètre du cercle est : " + 2 * Math.PI * rayon);
		scann.close();
	}
}
