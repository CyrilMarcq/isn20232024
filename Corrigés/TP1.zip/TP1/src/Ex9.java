
public class Ex9 {

	public static void main(final String[] args) {
		for (int i = 1; i <= 100; i++) {
			System.out.println(i);
		}
	}
}
