import java.util.Scanner;

public class Ex8bis {

	public static void main(final String[] args) {

		Scanner scann = new Scanner(System.in);
		System.out.print("Entrez un mois : ");
		String mois = scann.next();
		System.out.print("Entrez une année : ");
		int annee = scann.nextInt();

		switch (mois.toLowerCase()) {
		case "janvier":
		case "mars":
		case "mai":
		case "juillet":
		case "aout":
		case "octobre":
		case "decembre":
			System.out.println("31");
			break;
		case "avril":
		case "juin":
		case "septembre":
		case "novembre":
			System.out.println("30");
			break;
		case "fevrier":
			if (annee % 400 == 0 || (annee % 4 == 0 && annee % 100 != 0))
				System.out.println("29");
			else
				System.out.println("28");
			break;
		}

		scann.close();
	}
}
