import java.util.Scanner;

public class Ex8 {

	public static void main(final String[] args) {

		Scanner scann = new Scanner(System.in);
		int mois = scann.nextInt();
		int annee = scann.nextInt();

		switch (mois) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			System.out.println("31");
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			System.out.println("30");
			break;
		case 2:
			if (annee % 400 == 0 || (annee % 4 == 0 && annee % 100 != 0))
				System.out.println("29");
			else
				System.out.println("28");
			break;
		}
		
		scann.close();
	}
}
