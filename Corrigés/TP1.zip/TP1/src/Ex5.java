import java.util.Scanner;

public class Ex5 {

	public static void main(String[] args) {
		System.out.print("Saisissez un age : ");
		Scanner scann = new Scanner(System.in);
		int age = scann.nextInt();
		if (age < 18) {
			System.out.println("Mineur");
		} else {
			System.out.println("Majeur");
		}
		scann.close();
	}
}
