
public class Ex12 {

	public static void main(String[] args) {
		int a = 1;
		int b = 2;
		int tmp;

		System.out.println("Avant échange, a = " + a + ", b = " + b);
		tmp = a;
		a = b;
		b = tmp;

		System.out.println("Après échange, a = " + a + ", b = " + b);
	}
}
